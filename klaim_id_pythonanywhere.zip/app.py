import os
import json
import base64
import urllib.request
import urllib.parse
from flask import Flask, render_template, request, redirect, url_for, flash, session
import sheets_helper

app = Flask(__name__)
app.secret_key = 'super_secret_key_klaim_id' # For flash messages

ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg'} # Imgur only accepts images

def allowed_file(filename):
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def upload_to_imgur(file_stream):
    try:
        # Read file into memory and encode to base64
        base64_image = base64.b64encode(file_stream.read()).decode('utf-8')
        
        # We use a public test Client-ID for Imgur API
        # Note: In a production app, you should create your own Imgur app and use its Client-ID
        client_id = '546c25a59c58ad7'
        
        data = urllib.parse.urlencode({'image': base64_image}).encode('utf-8')
        req = urllib.request.Request('https://api.imgur.com/3/image', data=data)
        req.add_header('Authorization', f'Client-ID {client_id}')
        
        with urllib.request.urlopen(req) as response:
            res_data = json.loads(response.read().decode('utf-8'))
            if res_data.get('success'):
                return res_data['data']['link']
    except Exception as e:
        print(f"Error uploading to Imgur: {e}")
    return None

@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        nama = request.form.get('nama')
        kegiatan = request.form.get('kegiatan')
        nominal = request.form.get('nominal')
        bank = request.form.get('bank')
        rekening = request.form.get('rekening')
        
        if 'bukti' not in request.files:
            flash('Tidak ada file bukti yang diupload', 'error')
            return redirect(request.url)
            
        file = request.files['bukti']
        if file.filename == '':
            flash('Tidak ada file yang dipilih', 'error')
            return redirect(request.url)
            
        if file and allowed_file(file.filename):
            # Upload to Imgur directly from memory
            imgur_link = upload_to_imgur(file.stream)
            bukti_path = imgur_link if imgur_link else "Gagal Upload Gambar"
            
            # Save to SQLite database
            import database
            conn = database.get_db_connection()
            conn.execute('INSERT INTO reimbursements (nama, kegiatan, nominal, bank, rekening, bukti_path) VALUES (?, ?, ?, ?, ?, ?)',
                         (nama, kegiatan, float(nominal), bank, rekening, bukti_path))
            conn.commit()
            conn.close()
            
            # Save to Google Sheets
            try:
                sheets_helper.append_row(nama, kegiatan, float(nominal), bank, rekening, 'Pending', bukti_path)
            except Exception as e:
                print(f"Failed to save to Google Sheets: {e}")
            
            flash('Pengajuan rembes berhasil dikirim!', 'success')
            return redirect(url_for('index'))
        else:
            flash('Tipe file tidak diizinkan. Untuk versi Vercel, mohon gunakan JPG/PNG (PDF tidak didukung).', 'error')
            return redirect(request.url)

    return render_template('index.html')


@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        
        # Hardcoded credentials for MVP
        if username == 'admin' and password == 'admin123':
            session['admin_logged_in'] = True
            flash('Login berhasil!', 'success')
            return redirect(url_for('admin'))
        else:
            flash('Username atau password salah', 'error')
            
    return render_template('login.html')

@app.route('/logout')
def logout():
    session.pop('admin_logged_in', None)
    flash('Anda telah logout.', 'success')
    return redirect(url_for('login'))

@app.route('/admin')
def admin():
    if not session.get('admin_logged_in'):
        return redirect(url_for('login'))
        
    import database
    conn = database.get_db_connection()
    # Get all reimbursements
    reimbursements = conn.execute('SELECT * FROM reimbursements ORDER BY id DESC').fetchall()
    
    # Calculate stats
    total_pengajuan = len(reimbursements)
    total_pending = sum(1 for r in reimbursements if r['status'] == 'Pending')
    total_approved = sum(1 for r in reimbursements if r['status'] == 'Approved')
    
    conn.close()
    
    return render_template('admin.html', 
                           reimbursements=reimbursements,
                           total_pengajuan=total_pengajuan,
                           total_pending=total_pending,
                           total_approved=total_approved)

@app.route('/admin/update/<int:id>', methods=['POST'])
def update_status(id):
    if not session.get('admin_logged_in'):
        return redirect(url_for('login'))
        
    import database
    new_status = request.form.get('status')
    if new_status in ['Approved', 'Rejected']:
        conn = database.get_db_connection()
        conn.execute('UPDATE reimbursements SET status = ? WHERE id = ?', (new_status, id))
        conn.commit()
        conn.close()
        flash(f'Status pengajuan #{id} berhasil diupdate menjadi {new_status}.', 'success')
    return redirect(url_for('admin'))


# Vercel needs the app exposed
if __name__ == '__main__':
    app.run(debug=True, port=5000)
